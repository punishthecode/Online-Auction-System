-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3406
-- Generation Time: Jan 24, 2022 at 06:48 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 5.6.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `auction`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderId` int(11) NOT NULL,
  `BuyerUsr` varchar(15) NOT NULL,
  `SellerUsr` varchar(15) NOT NULL,
  `Amount` float NOT NULL,
  `Address` varchar(100) NOT NULL,
  `productId` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productId` int(11) NOT NULL,
  `productName` varchar(20) NOT NULL,
  `maxbid` float NOT NULL,
  `minbid` float NOT NULL,
  `quantity` int(11) NOT NULL,
  `sellerUsr` varchar(15) NOT NULL,
  `descp` varchar(150) NOT NULL,
  `currBid` float NOT NULL,
  `expiry` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(15) NOT NULL,
  `pass` varchar(15) DEFAULT NULL,
  `first_name` varchar(10) DEFAULT NULL,
  `last_name` varchar(10) DEFAULT NULL,
  `dob` varchar(8) DEFAULT NULL,
  `role` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



CREATE VIEW `admin_ex` AS
SELECT `P`.`productId`, `P`.`productName`, `P`.`currBid`, `P`.`expiry`, `P`.`sellerUsr`, `O`.`OrderId`, `O`.`BuyerUsr`, `O`.`Amount`, `O`.`Address`, `O`.`status`
FROM  `product` `P`, `orders` `O` 
WHERE `P`.`productId`=`O`.`productId`;

CREATE VIEW `bid_ex` AS
SELECT `P`.`productId`, `P`.`productName`,`P`.`maxbid`, `P`.`minbid`, `P`.`currBid`, `O`.`OrderId`, `O`.`Amount`, `O`.`status`
FROM  `product` `P`, `orders` `O` 
WHERE `P`.`productId`=`O`.`productId`;


--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderId`),
  ADD KEY `BuyerUsr` (`BuyerUsr`),
  ADD KEY `SellerUsr` (`SellerUsr`),
  ADD KEY `productId` (`productId`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productId`),
  ADD UNIQUE KEY `productId` (`productId`),
  ADD KEY `sellerUsr` (`sellerUsr`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `username` (`username`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`BuyerUsr`) REFERENCES `users` (`username`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`SellerUsr`) REFERENCES `users` (`username`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`productId`) REFERENCES `product` (`productId`) ON DELETE CASCADE;

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`sellerUsr`) REFERENCES `users` (`username`) ON DELETE CASCADE;
  
  
  
  
--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `pass`, `first_name`, `last_name`, `dob`, `role`, `email`) VALUES
('admin', 'admin', 'admin1', 'adminpass', '27/11/97', 'svp', 'admin@gmail.com'),
('buyer', 'buyer', 'test1', 'test1', '26/12/97', 'buyer', 'test1@gmail.com'),
('neeraj', 'neeraj', 'Neeraj', 'Skanda BR', '24/05/01', 'svp', 'neera@gmail.com'),
('nid', 'nid', 'Nidish', 'G', '30/10/00', 'buyer', 'nidgan007@gmail.com'),
('phan', 'phan', 'Phanish', 'SN', '05/07/01', 'seller', 'phan@gmail.com'),
('seller', 'seller', 'test2', 'test2', '07/01/97', 'seller', 'test2@gmail.com');
  

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productId`, `productName`, `maxbid`, `minbid`, `quantity`, `sellerUsr`, `descp`, `currBid`, `expiry`) VALUES
(1, 'Regal Imported ', 1251, 750, 19, 'seller', 'Premium Soap imported from USA. Each Box contains 2 bricks.', 0, '2022-10-28'),
(3, 'Scented Candles', 3800, 2100, 33, 'seller', 'Set of 10 scented candles. Scented rose', 2101, '2022-12-31'),
(4, 'Apple Wireless ', 13000, 8000, 4, 'phan', 'Imported Apple Wireless Keyboard with touch bar', 0, '2022-10-31'),
(6, 'Super Slime', 310, 120, 6, 'seller', 'Super Slime with infinite life', 0, '2022-10-30'),
(7, 'Dell XPS 13 201', 230000, 175000, 3, 'phan', 'Latest version of the XPS 13 Series. Imported from USA', 175001, '2022-12-27'),
(8, 'Death Note Note', 600, 350, 7, 'phan', 'Official Death Note Merchandise. Has 120 Pages.', 0, '2022-11-17'),
(9, 'Magnet Perfume', 13500, 10000, 3, 'phan', 'Synthetic perfume imported form France', 0, '2022-11-04'),
(10, 'Tanishq Gold Wa', 200000, 75000, 1, 'phan', '22K gold watch with hall mark. ', 0, '2022-12-31'),
(11, 'Test', 100000, 123, 8, 'seller', 'This is a genuine test product, buy now at cheap price', 124, '2022-01-27');

-- --

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderId`, `BuyerUsr`, `SellerUsr`, `Amount`, `Address`, `productId`, `Quantity`, `status`) VALUES
(1, 'buyer', 'seller', 501, 'benaluru', 1, 1, 1),
(2, 'buyer', 'seller', 2101, 'rr nagar', 3, 1, 0),
(3, 'nid', 'seller', 123, 'test area', 11, 1, 0),
(4, 'nid', 'seller', 124, 'hello oaddress', 11, 1, 0);

-- --------------------------------------------------------

  
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
