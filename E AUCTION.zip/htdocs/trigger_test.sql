CREATE TABLE `notify` (
  `username` varchar(15) NOT NULL,
  `OrderId` varchar(15) DEFAULT NULL,
  `productId` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


delimiter //
CREATE TRIGGER `upd_check` AFTER UPDATE ON `orders`
       FOR EACH ROW
       BEGIN
           INSERT INTO `notify` VALUES (new.username,new.OrderId,new.ProductId,new.);
       END;//
delimiter ;
