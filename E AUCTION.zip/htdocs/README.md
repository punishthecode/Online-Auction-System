# Online Auction Portal
Simple PHP based website for Online Auctions.
