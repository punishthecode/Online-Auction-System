<!DOCTYPE html>
<?php
  session_start();
  $_SESSION["logged"]="";
  $_SESSION["Name"]="";
  $db=mysqli_connect('localhost:3406','root','','auction') or die("Connection Failed");
  if (isset($_GET["err"]) and $_GET["err"]==1)
      echo "Please Login";
?>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login and More</title>
    <link rel=stylesheet type="text/css" href=style.css>
		<style type="text/css">
		<style>
      *{
        margin:4px;
      }
      body{
      	/* margin:70px;*/
        font-family:sans-serif;
		background:url('assets/images/bg-blur.png');
		background-repeat: repeat-y;
		background-size: cover;
        background-color: powderblue;
      }
	  
      ul{
		left: 0;
    	list-style-type: none;
   	 	margin: 0;
  	  	padding: 0;
    	overflow: hidden;
    	background-color: rgb(108,215,228);
    	position: fixed;
    	top: 0;
    	width: 100%;
	  }
	fieldset{
		border:0;
	}
	li{	
    	float: left;
	}

    li a {
    display: block;
    color: black;
	font-weight: bold;
    text-align: center;
    padding: 33px 20px;
    text-decoration: none;
 }

   li a:hover:not(.active) {
	   color:white;
    background-color: #111;
 }

   .active {
    background-color: #4CAF50;
 }
 .pseudolink { 
   color:blue; 
   text-decoration:underline; 
   cursor:pointer; 
   }
   
   .title{
	   margin-bottom:20px;
   }
   hr{
		margin-top:20px;
		margin-bottom:35px;
   }
   #login{
	     background:rgba(39, 208, 245, 0.4);
   }
  	</style>

  </head>
  <body>
		<!--<div style="text-align: center;">
			<nav class="navbar navbar-light navbar-expand-md navigation-clean-button" style="background: rgb(108,215,228);">
				<div class="container"><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button><img src="assets/img/7d9c1fb259e09760c50fc9f336ffe21f.png" style="width: 150px;"><a class="navbar-brand" href="#" style="font-family: 'Alfa Slab One', serif;font-weight: bold;font-style: italic;font-size: 35px;">Online Auction Platform</a>
					<div class="collapse navbar-collapse" id="navcol-1">
						<ul class="navbar-nav me-auto">
							<li class="nav-item"></li>
						</ul><span class="navbar-text actions"> <a class="btn btn-light action-button" role="button" href="/login.php" style="background: rgb(176,224,230);color: rgb(0,0,0);font-weight: bold;font-family: Amaranth, sans-serif;font-size: 25px;">Login</a></span>
					</div>
				</div>
			</nav>
		</div>-->
		<ul><li><span class="pseudolink" onclick="location='index.php'"><img class="" src="assets/img/7d9c1fb259e09760c50fc9f336ffe21f.png" style="height:80px;width: 100px;"></span></li>
  			<li><a class="" href="index.php">Home Page</a></li>
  			<!-- <li><a href="addTender.php">Add Tender</a></li> -->
  			<li><a class="active" href="login.php">Login</a></li>
			<!--<li><a href="Support.php">Support</a></li>-->
			<li><a href="index.php">Logout</a><li>
		</ul>
  	<center><h3 style="padding-top:50px;">Online Auction & Bidding System</h3><center>
    <?php
      if($_SERVER["REQUEST_METHOD"]=="POST")
      {
        $usr=$_POST['usr'];
        $pass=$_POST['passwd'];
        if(isset($_POST['category']))
        	$cat=$_POST['category'];
		//if($cat=null)
		//{
		//	$error=	"Wrong Category or no category selected";
		//}
        $query="select username from users where username='$usr' and pass='$pass' and role='$cat';";
        $result=mysqli_query($db,$query) or die("failed");
        $count=mysqli_num_rows($result);
        if($count!=1)
        {
          $error="wrong Username \n or password \n or category";
        }
        else
        {
          $_SESSION["logged"]=$cat;;
          $_SESSION["Name"]=$usr;
          if($cat=="buyer")
          	header("location: Listings.php");
          else if($cat=="seller")
          	header("location: Seller_portal.php");
          else
          	header("location: svp.php");
        }
      }
     ?>

    <center>
    <form id="login" method="post" action="">
      <p class="title">Log in</p>
	<!-- <div style="white-space:nowrap;display:inline;">
       <label for="buyer">Buyer<input type="radio" name='category' value="buyer"></label> 
       <label for="seller">Seller<input type="radio" name='category' value="seller"></label>
       <label for="svp">Admin<input type="radio" name='category' value="svp"></label>
	 </div> 
	 -->
	 <select name="category" id="category">
		<option value="buyer">Buyer</option>
		<option value="seller">Seller</option>
		<option value="svp">Admin</option>
	</select>
<br><hr>
      <input type="text" placeholder="Username" id='usr' name='usr' autofocus requried/>
      <input type="password" placeholder="Password" id='passwd' name='passwd' required/>
      <?php
        if(isset($error) && !empty($error))
        {
          echo "<p id='error'> $error </p>";
        }
        mysqli_close($db);
       ?>
      <button type="submit" style="background:black; cursor:pointer" id='lgin'>
        Log In
      </button>
    </form>
  </center>

  </body>
</html>
