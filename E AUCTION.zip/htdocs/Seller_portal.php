<?php
	session_start();
    if($_SESSION["logged"]!="seller")
    header("location: index.php");
	$name=$_SESSION['Name'];
	echo "<title> Welcome $name </title>";
?>
<html>
  <head>
<style type="text/css">
      <style>
      *{
        margin:0px;
      }
      body{
		  padding-top:70px;
        margin: 70px;
        font-family:sans-serif;
		background:url('assets/images/bg-blur.png');
		background-repeat: repeat-y;
		background-size: cover;
        background-color: powderblue;
      }
      table{
		   background: rgba(39, 208, 245, 0.3);
		  text-align:center;
        border-collapse: collapse;
      }
      tr,td,th{
        border-style:solid;
      }
      input, button, textarea{
        background: #2196F3;
        border-width: 1px;
        color: #fff;
        border-radius:5px;
      }
	  fieldset{
		border:0;
	}
      ul{
		  left:0;
      list-style-type: none;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background-color: rgb(108,215,228);
      position: fixed;
      top: 0;
      width: 100%;
    }

  li{ 
      float: left;
  }

    li a {
		font-weight:bold;
    display: block;
    color: black;
    text-align: center;
    padding: 33px 30px;
    text-decoration: none;
 }

   li a:hover:not(.active) {
	   color:white;
    background-color: #111;
 }

   .active {
	   
    background-color: #4CAF50;
 }
    label{
      display: inline-block;
      width: 260px;
      float:left;
      text-align: left;
    }
	 .pseudolink { 
   color:blue; 
   text-decoration:underline; 
   cursor:pointer; 
   }
     </style>
  </head>
 	<body>
	<?php
		$name=$_SESSION['Name'];
		echo "<h3> Welcome to the dashboard <span style=\"color: #ff0000\"> $name</span>, </h3>";
		?>
 		<ul><li><span class="pseudolink" onclick="location='index.php'"><img src="assets/img/7d9c1fb259e09760c50fc9f336ffe21f.png" style="height:80px;width: 100px;"></span></li>
  			<li><a class="active" href="Seller_portal.php">Add Product</a></li>
  			<li><a href="Seller_orders.php">My Orders</a></li>
  			<!--<li><a href="tenders.php">Tenders</a></li>-->
  			<li><a href="MyProducts.php">My Products</a></li>
        <li><a href="index.php">Logout</a><li>
		</ul>

 			<form name='add_product' method="POST" action="landing_page.php" >
 				<label>Enter the Name of your Product </label> <input type="text" name="name" value=""><br>
 				<label>Enter the Minimum Bid</label> <input type="text" name="minbid" value=""><br>
 				<label>Enter the Maximum Bid </label><input type="text" name="maxbid" value=""><br>
 				<label>Enter the Quantity Available</label> <input type="text" name="qty" value=""><br><br>
 				<label>Enter Item Description</label> <textarea rows='4' columns='10' name='desc' value=""></textarea><br>
 				<label>Enter the Expiry </label><input type="date" name="expiry" value=""></br>
 				<button type="submit" name="submit" value=1> Add Product </button>
 			</form>
  	</body>
</html>	