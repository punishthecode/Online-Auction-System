<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Auction Arena</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alfa+Slab+One&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Amaranth&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Armata&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body style="border-style: none;">
    <div style="text-align: center;">
        <nav class="navbar navbar-light navbar-expand-md navigation-clean-button" style="background: rgb(108,215,228);">
            <div class="container"><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button><img src="assets/img/7d9c1fb259e09760c50fc9f336ffe21f.png" style="width: 150px;"><a class="navbar-brand" href="#" style="font-family: 'Alfa Slab One', serif;font-weight: bold;font-style: italic;font-size: 35px;">Online Auction Platform</a>
                <div class="collapse navbar-collapse" id="navcol-1">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item"></li>
                    </ul><span class="navbar-text actions"> <a class="btn btn-light action-button" role="button" href="/login.php" style="background: rgb(176,224,230);color: rgb(0,0,0);font-weight: bold;font-family: Amaranth, sans-serif;font-size: 25px;">Login</a></span>
                </div>
            </div>
        </nav>
        <div class="row" style="background: powderblue;">
            <div class="col offset-lg-0">
                <p style="font-size: 45px;font-family: 'Alfa Slab One', serif;font-style: italic;text-align: center;">Online Auction!!</p>
                <p style="height: 50;font-size: 30px;text-align: center;font-family: Armata, sans-serif;font-weight: bold;">Buy and sell your priced possessions.</p>
                <p style="font-size: 30px;font-family: Armata, sans-serif;font-weight: bold;text-align: center;">Online Auction allows you to buy and sell items in real time without any hassle!.</p>
                <p style="font-size: 30px;font-family: Armata, sans-serif;font-weight: bold;text-align: center;">Buy and sell your items quickly and safely.</p><a href="/login.php"><button class="btn btn-primary" type="button" style="text-align: center;font-weight: bold;background: rgb(108,215,228);border-style: none;transform: perspective(0px) scale(1.50);margin: 20px;color: rgb(0,0,0);">Get Started!!</button></a>
            </div>
        </div>
        <div class="row">
            <div class="col" style="background: #b0e0e6;"><img src="assets/img/auction.png" style="background: #b0e0e6;width: 1000px;text-align: center;border-style: solid;border-color: rgb(33, 37, 41);border-top-color: rgb(33,;border-right-color: 37,;border-bottom-color: 41);border-left-color: 37,;">
                <div class="row">
                    <div class="col">
                        <p style="font-size: 40px;font-family: Armata, sans-serif;font-weight: bold;text-align: center;padding: 18px;">Developers</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col" style="background: #b0e0e6;">
                        <p style="font-size: 30px;font-weight: bold;font-family: Armata, sans-serif;">Phanish S N</p>
                        <p style="font-size: 20px;font-family: Armata, sans-serif;font-weight: bold;">Project Developer</p>
                    </div>
                    <div class="col" style="background: #b0e0e6;"><img src="assets/img/1.jpeg" style="width: 200px;"></div>
                </div>
            </div>
            <div class="col">
                <div class="row">
                    <div class="col" style="font-size: 30px;font-family: Armata, sans-serif;font-weight: bold;background: #b0e0e6;">
                        <p>Nidish G</p>
                        <p style="font-size: 20px;">Project Developer</p>
                    </div>
                    <div class="col" style="background: #b0e0e6;"><img src="assets/img/dsBuffer.bmp.png" style="width: 200px;"></div>
                </div>
            </div>
        </div>
        <div class="row" style="background: #b0e0e6;">
            <div class="col">
                <div class="row">
                    <div class="col" style="padding: 20px 20px;">
                        <p style="font-size: 30px;font-weight: bold;font-family: Armata, sans-serif;">Neeraj Skanda BR</p>
                        <p style="font-size: 20px;font-weight: bold;font-family: Armata, sans-serif;">Project Developer</p>
                    </div>
                    <div class="col" style="padding: 20px ;"><img src="assets/img/8d611cdc-84d3-40da-ae0f-35341520a988.jpg" style="width: 200px;padding: 1px;"></div>
                </div>
            </div>
            <div class="col" style="background: #b0e0e6;">
                <p style="font-size: 30px;font-weight: bold;font-family: Armata, sans-serif;padding: 43px;">Online Auction System</p>
                <p style="font-size: 20px;font-weight: bold;font-family: Armata, sans-serif;">Co-Developed by Phanish S N, Neeraj Skanda B R, Nidish G for Fifth semester DBMS Laboratory</p>
            </div>
        </div>
        <footer>
            <p style="font-size: 15px;font-weight: bold;font-family: Armata, sans-serif;background: #b0e0e6;"><i class="fa fa-copyright"></i></p>
            <p style="font-size: 15px;font-weight: bold;font-family: Armata, sans-serif;padding: -7px;margin: -18px;background: #b0e0e6;">Copyright 2022.All rights reserved.</p>
        </footer>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>