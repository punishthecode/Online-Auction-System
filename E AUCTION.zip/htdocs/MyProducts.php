<?php
	session_start();
    if($_SESSION["logged"]!="seller")
    header("location: index.php");
	$name=$_SESSION['Name'];
	echo "<title> Welcome $name </title>";
	$db=mysqli_connect('localhost:3406','root','','auction') or die("Connection Failed");
?>
<html>
  <head>
  	<style type="text/css">
  		<style>
      *{
        margin:4px;
      }
      body{
		  padding-top:70px;
      	margin: 70px;
        font-family:sans-serif;
		background:url('assets/images/bg-blur.png');
		background-repeat: repeat-y;
		background-size: cover;
        background-color: powderblue;
      }
      table{
		   background: rgba(39, 208, 245, 0.3);
		  text-align:center;
        border-collapse: collapse;
      }
      tr,td,th{
        border-style:solid;
      }
      input, button{
		  padding: 10px 30px;
        background: #2196F3;
        border: none;
        left: 0;
        color: #fff;
        bottom: 0;
        border: 0px solid rgba(0, 0, 0, 0.1);
        border-radius:5px;
        
        transition: all 0.1s ease-out;
      }
      ul{
		  left:0;
    	list-style-type: none;
   	 	margin: 0;
  	  	padding: 0;
    	overflow: hidden;
    	background-color: rgb(108,215,228);
    	position: fixed;
    	top: 0;
    	width: 100%;
	  }
	
	fieldset{
		border:0;
	}
	
	li{	
    	float: left;
	}

    li a {
		font-weight:bold;
    display: block;
    color: black;
    text-align: center;
    padding: 33px 30px;
    text-decoration: none;
 }

   li a:hover:not(.active) {
	   color:white;
    background-color: #111;
 }

   .active {
    background-color: #4CAF50;
 }
  .pseudolink { 
   color:blue; 
   text-decoration:underline; 
   cursor:pointer; 
   }
  	</style>
  </head>
 	<body>
		<?php
		$name=$_SESSION['Name'];
		echo "<h3> Welcome to the dashboard <span style=\"color: #ff0000\"> $name</span>, </h3>";
		?>
		
 		<ul><li><span class="pseudolink" onclick="location='index.php'"><img src="assets/img/7d9c1fb259e09760c50fc9f336ffe21f.png" style="height:80px;width: 100px;"></span></li>
  			<li><a href="Seller_portal.php">Add Product</a></li>
  			<li><a href="Seller_orders.php">My Orders</a></li>
  			<!--<li><a href="tenders.php">Tenders</a></li>-->
        <li><a class="active"  href="myproducts.php">My Products</a></li>
        <li><a href="index.php">Logout</a><li>
		</ul>

      <fieldset>
 			<form name='myproducts' method="POST" action="DeleteProduct.php" >
        <table>
        <tr>
          <th>Product Id</th>
          <th>Product Name</th>
          <th>Minimum Bid</th>
          <th>Maximum Bid</th>
          <th>Current Bid</th>
          <th>Stock</th>
          <th>Description</th>
          <th>Time Left</th>
         
        </tr>
        <?php
        $query="SELECT * FROM product where sellerUsr='$name';";
        mysqli_query($db,$query);
        $result=mysqli_query($db,$query);
        while($row=mysqli_fetch_array($result)){
          echo '<tr>';
          echo '<td>'.$row['productId'].'</td>';
          echo '<td>'.$row['productName'].'</td>';
          echo '<td>'.$row['minbid'].'</td>';
          echo '<td>'.$row['maxbid'].'</td>';
          echo '<td>'.$row['currBid'].'</td>';
          echo '<td>'.$row['quantity'].'</td>';
          echo '<td>'.$row['descp'].'</td>';
          $d1=date_create($row['expiry']);
          $d2=date_create(date('d-m-Y'));

          $diff=date_diff($d2,$d1);

          if($diff->format("%R%a")<0){
            echo '<td>Expired</td>';
            //$row['productId']=-1;
          }
          else if($diff->format("%R%a")==0)
            echo '<td>Last Day</td>';
          else
            echo '<td>'.$diff->format("%a").' days left</td>';

          echo "<td> <button type='submit' name='Delete' value=".$row['productId'].">Delete</button></td>";
          echo '</tr>';
        }
        echo '</table>';
        mysqli_close($db);
        ?>
  	</body>
</html>